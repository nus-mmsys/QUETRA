#!/usr/bin/Rscript


df <- read.table("result.log", header = FALSE)
x<-df[4];
y<-df[3];
z<-df[1];
u<-df[2];
v<-df[5];
a <- matrix(c(0,0,0,0,0,0,0,0,0,0), ncol=1)
b <- matrix(c(" "," "," "," ", " "," "," "," "," "," "), ncol=1)
e <- matrix(c(0,0,0,0,0,0,0,0,0,0), ncol=1)
print (x[ 4,]);

for(j in 0:20)
{

for (i in 1:10)
{
  a[i]<-x[i+j*10,]
  b[i]<-paste(y[i+j*10,])
  e[i]<-v[i+j*10,]
  c<-paste(z[i+j*10,],u[i+j*10,],"R Avg")
  d<-paste(z[i+j*10,],u[i+j*10,],"# R changes")
}

print (a[ 4]);
print (b[ 4]);
print (e[ 4]);


par(mar=c(4,4,4,0.1))
aa<-barplot(a, width = 0.5, space = 4, beside=TRUE, horizontal=TRUE,names.arg = b , main=c, density = 100 , ylab="Kbps", col=c(160) ,axisnames=a) 
text(x=aa, y=a, labels=a, pos=3,xpd=NA)


bb<-barplot(e, width = 0.3, space = 0.9, beside=TRUE, names.arg = b , main=d, density = 100 , ylab=" # ", col=c(160) ) 
text(x=bb, y=e, labels=e, pos=3,xpd=NA)

}


